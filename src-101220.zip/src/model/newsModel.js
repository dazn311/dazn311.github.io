let list = [
    { id: 0, value: "super anegdot", icon_url: "", isFavorite: false },
    { id: 1, value: "super anegdot 2", icon_url: "", isFavorite: true },
    { id: 2, value: "super anegdot 3", icon_url: "", isFavorite: false },

]



export default list